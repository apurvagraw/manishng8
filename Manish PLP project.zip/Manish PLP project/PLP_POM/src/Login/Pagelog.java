package Login;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import Pomlib.*;

import com.cg.excel.*;

//import dataExcel.ExcelSheet;


public class Pagelog {
	
	WebDriver driver;
	By account =By.xpath(".//*[@id='top-links']/ul/li[2]/a/i");
	By logclick =By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a");
	By emailId= By.name("email");
	By password=By.id("input-password");
	By Loginbtn=By.cssSelector("input.btn.btn-primary");
	By search=By.xpath("(//button[@type='button'])[4]");
	By item=By.name("search");
	By rightmsg=By.xpath("//div[@id='content']/h2");
	By rightnoproduct=By.xpath("//div[@id='content']/p[2]");
	By category=By.name("category_id");
	By searchbutton=By.cssSelector("#button-search");
	By subcategory= By.name("sub_category");
	By desc_checkbx=By.id("description");
    By inputsearch=By.id("input-search"); 
	
	

	String str="";
	String str1="";
	String itm="";
 
 public void login (WebDriver driver)
	{
		
		this.driver=driver;
		
	}  
	
	public void acc()
	{
		driver.findElement(account).click();
		driver.findElement(logclick).click();
	}
	public void logbtn()
	{
		driver.findElement(Loginbtn).click();
	
	}
	
	
	public void setUsereml(String streml,String str)
	{
		driver.findElement(emailId).sendKeys(str);
	}

	public void setPassword(String strPassword,String str1)
	{
		driver.findElement(password).sendKeys(str1);
	}
	
	public void searching(String itm)
	{
		
		driver.findElement(item).sendKeys(itm);
		driver.findElement(search).click();
	}
	
	
	
	public void loginToSearch(String streml,String strPassword) throws BiffException, IOException, InterruptedException {
		read r=new read();
		int totalNoOfRows =r.nofRows();
		// To get the number of columns present in sheet
		int totalNoOfCols =r.nofCols();
		this.acc();
		int row=1,col;
		for(row=1;row<totalNoOfRows;row++)
		{	
			driver.findElement(emailId).clear();
			driver.findElement(password).clear();
			
		
	
		for(col=0;col<totalNoOfCols;col++)
		{
			if(col==0)
			{ 
				this.setUsereml(streml,r.readExcel(col,row));
			}
			if(col==1)
			{
				this.setPassword(strPassword,r.readExcel(col,row));
			}
			
		
		Thread.sleep(1000);
		}
		this.logbtn();
		}	
	    //this.setUsereml(streml,str);
	    //this.setPassword(strPassword,str1);
	
		
	}
	
	
	
	 
	public void validation()
	{

		String sermsg1="Products meeting the search criteria";
		String s= driver.findElement(rightmsg).getText();
	
		  if(s.contentEquals(sermsg1))
		  {
			System.out.println("message for search criteria exist");
		  }
		  else
		  {
			  System.out.println("message for search criteria does not exist");
		  }
		}
	
	
	public void productnoexist()
	{
		String sermsg2="There is no product that matches the search criteria.";
		try{
		String s1=driver.findElement(rightnoproduct).getText();
		
		  if(s1.contentEquals(sermsg2))
		  {
			System.out.println("product with search criteria does not exist");
		  }
		}
		catch(Exception e)
		{
			System.out.println("product with search criteria exists");	
		}
		
	}
	
	public void wrongcategory() 
	{
		Select c= new Select(driver.findElement(category));
		//Thread.sleep(10000);
		c.selectByValue("31");
		//Thread.sleep(10000);
		driver.findElement(searchbutton).click();
		productnoexist();
	}
	
	public void sub_category()
	{
		Select d= new Select(driver.findElement(category));
		//Thread.sleep(10000);
		d.selectByValue("24");
		driver.findElement(subcategory).click();
		driver.findElement(searchbutton).click();
		productnoexist();
	}
	
	public void product_desc() 
	{
		
		Select e= new Select(driver.findElement(category));
	//	Thread.sleep(10000);
		e.selectByValue("24");
		driver.findElement(subcategory).click();
	//	Thread.sleep(10000);
		driver.findElement(desc_checkbx).click();
	//	Thread.sleep(10000);
		driver.findElement(searchbutton).click();
		productnoexist();
	}
	
	public void all_category() 
	{
		driver.findElement(inputsearch).clear();
		Select f= new Select(driver.findElement(category));
	//	Thread.sleep(10000);
		f.selectByValue("0");
		driver.findElement(searchbutton).click();
		productnoexist();
		
	}

	
	
	 
	}
		
	

	
	 


