package utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Smpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		driver.get("https:\\demo.opencart.com");
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a/i")).click();
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
		
	}

}
