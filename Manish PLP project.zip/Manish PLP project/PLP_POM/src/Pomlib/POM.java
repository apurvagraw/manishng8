package Pomlib;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import jxl.read.biff.BiffException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Login.Pagelog;



public class POM {
	
	WebDriver driver;
	Pagelog  objlog =new Pagelog();

//Opening WebSite
   @BeforeTest
   public void setup()
   {
	   driver=new FirefoxDriver();
	   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	   driver.get("https:\\demo.opencart.com");
	   
   }
	
//We can use HashMap method to map the excel data 
   
   
  /*
   
   
   @Test(dataProvider="data", priority=1)
    public void integrationTest(Map<String, String> map) throws InterruptedException, BiffException, IOException{
    	
    	//Pagelog objlog =new Pagelog();
	    objlog.login(driver);
		objlog.loginToSearch(map.get("UserName"), map.get("Password"));
		objlog.searching(map.get("itm"));
	} 
	
	
*/
   
   //login to page and searching for particular item o
   
   @Test(priority=1)
   public void loginpage() throws BiffException, IOException, InterruptedException
   {
	 
	   objlog.login(driver);
	   objlog.loginToSearch("UserName","Password");
	   objlog.searching("iphone");
	   
   }
   
   
   //validation for search criteria message exists or not
   
    
  @Test(priority=2)
	public void Search()
	{
		objlog.validation();
	}

  //validate that searched product exist or not
  
	@Test(priority=3)
	public void productexist()
{
		objlog.productnoexist();
	}
	
	//validate the message after entering wrong sub-category in category field
	
	
	 @Test(priority=4)
	public void category() 
	{
		objlog.wrongcategory();
	}
	
	 //validate the page after clicking  all category check box
	 
	 
	@Test(priority=5)
	public void category_checkbox() 
	{
		objlog.sub_category();
	}
	
	
	//validate the page after clicking product description  check box
	
	
	@Test(priority=6)
	public void desc_checkbox() 
	{
		objlog.product_desc();
	}
	
	
	//validate the page after selecting all category in category fieled
 
	@Test(priority=7)
	public void allcategory()
	{
		objlog.all_category();
	}

	
	
	// We can user data provider for calling excel file
	
	
	

/*	
@DataProvider(name = "data")
	  public Object[][] dataSupplier() throws IOException {
	    File file = new File("D://selenium_java//PLP_POM//src//Pomlib//book1.xlsx");
	    FileInputStream fis = new FileInputStream(file);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sheet = wb.getSheetAt(0);
	    wb.close();
	    int lastRowNum = sheet.getLastRowNum() ;
	    int lastCellNum = sheet.getRow(0).getLastCellNum();
	    Object[][] obj = new Object[lastRowNum][1];
	    for (int i = 0; i < lastRowNum-2; i++) {
	      Map<Object, Object> datamap = new HashMap<>();
	      for (int j = 0; j < lastCellNum; j++) {
	        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i+1).getCell(j).toString());
	      }
	      obj[i][0] = datamap;
	    }
	    return  obj;
	  }
*/

	
}
