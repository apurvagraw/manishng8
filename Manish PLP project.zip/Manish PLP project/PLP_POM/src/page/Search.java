package page;

import Login.Pagelog;

public class Search {
	
	
	
	public void logn(){
		
	Pagelog pg= new Pagelog();
	pg.loginToSearch("streml", "strPassword");
	}

	
}
