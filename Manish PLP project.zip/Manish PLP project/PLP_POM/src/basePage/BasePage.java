package basePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BasePage {
	
	
    WebDriver driver;
	public void BasePage (WebDriver driver)
	{
		
		this.driver=driver;
		
	}
	
	
	
    /*Click on element:
	*/
	public void click(String element){
	driver.findElement(By.xpath(element)).click();	
	}
	
	 /*Enter the text:
		*/
		public void enterText(String element, String text){
		driver.findElement(By.xpath(element)).sendKeys(text);;	
		}
}
